package demo.Mapper;

//import demo.pojo.chater;

import java.util.List;

//public interface chaterMapper {
//    List<chater> selectall();
//
//    int getCount();
//    void insertChater(int id,String name,String pwd);
//    String getPwd(String name);
//    int getId(String name);
//}
