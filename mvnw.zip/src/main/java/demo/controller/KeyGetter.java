package demo.controller;


import demo.config.WebSocket;
import demo.pojo.InitialKeyBundle;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class KeyGetter {
    @CrossOrigin
    @GetMapping(value = "/keyOf/{uid}")
    @ResponseBody
    public InitialKeyBundle key(@PathVariable String uid) {
        return WebSocket.getKeyBy(uid).initialKeyBundle();
    }
}
