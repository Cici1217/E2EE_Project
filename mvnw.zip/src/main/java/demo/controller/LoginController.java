package demo.controller;


import demo.pojo.User;
import demo.result.Result;
import demo.token.JWTUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;

@Controller
public class LoginController {
    @Autowired
    private HttpServletRequest request;

    @Autowired
    private RedisTemplate redisTemplate;


    @PostMapping("/redis/{k}/{v}")
    public String addStringKV(@PathVariable String k,
                              @PathVariable String v) {

        // 使用StringRedisTemplate对象
        redisTemplate.opsForValue().set(k, v);
        return "使用StringRedisTemplate对象添加";
    }


    public String getData(String key) {
        Object v = redisTemplate.opsForValue().get(key);
        return "key是" + key + ",它的值是:" + v;
    }


    @RequestMapping(value = "/login")
    @ResponseBody
    public Result login(@RequestBody User requestUser) {
        String username = requestUser.getUsername();
        String pwd=  requestUser.getPassword();
        String registrationID = requestUser.getRegistrationID();
        System.out.println("username"+username);
        System.out.println("pwd"+pwd);
        System.out.println("rID"+registrationID);
        return new Result(200);
    }

    @RequestMapping("/checkToken")
    public boolean check() {
        String token = request.getHeader("token");
        return JWTUtils.isExpire(token);
    }
}