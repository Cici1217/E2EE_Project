package demo.controller;


import demo.config.WebSocket;
import demo.pojo.KeyBundle;
import demo.result.Result;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class KeyReceiver {
    @CrossOrigin
    @PostMapping(value = "/keysOf/{uid}")
    @ResponseBody
    public Result receiveKey(@RequestBody KeyBundle keyBundle, @PathVariable String uid){
        System.out.println("Receive Key");
        System.out.println(keyBundle);
        System.out.println(keyBundle.getPreKeys().get(1));
        System.out.println(keyBundle.getIdentityKey());
        WebSocket.setKeyMap(uid, keyBundle);
        return new Result(200);
    }
}
